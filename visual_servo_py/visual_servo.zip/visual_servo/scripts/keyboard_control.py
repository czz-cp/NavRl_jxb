#!/usr/bin/env python3
import rospy
import numpy as np
import transforms3d as tf3d
from geometry_msgs.msg import Twist
from tf2_ros import Buffer, TransformListener
import tf2_py as tf2
import sys, select, termios, tty

class CameraKeyboardControl:
    def __init__(self):
        rospy.init_node('camera_keyboard_control')
        
        # 坐标系配置
        self.base_frame = "base"
        self.ee_frame = "tool0_controller"
        self.camera_frame = "camera_link"
        
        # 控制参数
        self.linear_speed = 0.1
        self.angular_speed = 0.5
        self.speed_increment = 0.02
        
        # 当前激活的控制方向
        self.active_linear_direction = None
        self.active_angular_direction = None
        
        # TF工具
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer)
        
        # 发布者
        self.cmd_pub = rospy.Publisher("/ur10e_robot/twist_controller/command", 
                                      Twist, queue_size=1)
        
        # 键盘设置
        self.settings = termios.tcgetattr(sys.stdin)
        
        rospy.loginfo("相机键盘控制已启动")
        rospy.loginfo("使用以下键控制相机运动:")
        rospy.loginfo("---------------------------")
        rospy.loginfo("w/s: 相机前进/后退")
        rospy.loginfo("a/d: 相机左移/右移")
        rospy.loginfo("q/e: 相机上移/下移")
        rospy.loginfo("u/j: 绕X轴旋转 (滚动)")
        rospy.loginfo("i/k: 绕Y轴旋转 (俯仰)")
        rospy.loginfo("o/l: 绕Z轴旋转 (偏航)")
        rospy.loginfo("+/-: 增加/减小速度")
        rospy.loginfo("空格: 停止运动")
        rospy.loginfo("x: 退出")
        rospy.loginfo("---------------------------")
        rospy.loginfo(f"当前线速度: {self.linear_speed} m/s, 角速度: {self.angular_speed} rad/s")
        
    def get_key(self):
        """获取键盘输入"""
        tty.setraw(sys.stdin.fileno())
        rlist, _, _ = select.select([sys.stdin], [], [], 0.1)
        if rlist:
            key = sys.stdin.read(1)
        else:
            key = ''
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.settings)
        return key

    def run(self):
        rate = rospy.Rate(30) 
        try:
            while not rospy.is_shutdown():
                key = self.get_key()
                
                # 处理速度调整
                if key == '+':
                    self.linear_speed += self.speed_increment
                    self.angular_speed += self.speed_increment
                    rospy.loginfo(f"速度增加: 线速度={self.linear_speed:.2f} m/s, 角速度={self.angular_speed:.2f} rad/s")
                elif key == '-':
                    self.linear_speed = max(0.01, self.linear_speed - self.speed_increment)
                    self.angular_speed = max(0.05, self.angular_speed - self.speed_increment)
                    rospy.loginfo(f"速度减小: 线速度={self.linear_speed:.2f} m/s, 角速度={self.angular_speed:.2f} rad/s")
                    
                # 处理运动控制
                if key == 'w':  # 相机前进
                    self.active_linear_direction = ('z', 1)
                elif key == 's':  # 相机后退
                    self.active_linear_direction = ('z', -1)
                elif key == 'a':  # 相机左移
                    self.active_linear_direction = ('x', -1)
                elif key == 'd':  # 相机右移
                    self.active_linear_direction = ('x', 1)
                elif key == 'q':  # 相机上移
                    self.active_linear_direction = ('y', 1)
                elif key == 'e':  # 相机下移
                    self.active_linear_direction = ('y', -1)
                elif key == 'u':  # 绕X轴正转
                    self.active_angular_direction = ('x', 1)
                elif key == 'j':  # 绕X轴反转
                    self.active_angular_direction = ('x', -1)
                elif key == 'i':  # 绕Y轴正转
                    self.active_angular_direction = ('y', 1)
                elif key == 'k':  # 绕Y轴反转
                    self.active_angular_direction = ('y', -1)
                elif key == 'o':  # 绕Z轴正转
                    self.active_angular_direction = ('z', 1)
                elif key == 'l':  # 绕Z轴反转
                    self.active_angular_direction = ('z', -1)
                elif key == ' ':  # 停止
                    self.active_linear_direction = None
                    self.active_angular_direction = None
                elif key == 'x':  # 退出
                    rospy.signal_shutdown("用户退出")
                    break
                
                # 初始化相机坐标系下的速度指令
                twist_cam = Twist()
                
                # 应用当前激活的线速度控制
                if self.active_linear_direction:
                    axis, sign = self.active_linear_direction
                    setattr(twist_cam.linear, axis, sign * self.linear_speed)
                
                # 应用当前激活的角速度控制
                if self.active_angular_direction:
                    axis, sign = self.active_angular_direction
                    setattr(twist_cam.angular, axis, sign * self.angular_speed)
                
                try:
                    # 只有在有运动指令时才进行变换和发布
                    if self.active_linear_direction or self.active_angular_direction:
                        # 将相机速度转换为末端速度
                        twist_ee = self.transform_twist_to_ee(twist_cam)
                        
                        # 将末端速度转换为基座速度
                        twist_base = self.transform_twist_to_base(twist_ee)
                        
                        # 发布速度指令
                        self.cmd_pub.publish(twist_base)
                        
                        # 打印控制信息
                        rospy.loginfo_throttle(0.5, f"发布速度: lin=({twist_base.linear.x:.2f},{twist_base.linear.y:.2f},{twist_base.linear.z:.2f}), ang=({twist_base.angular.x:.2f},{twist_base.angular.y:.2f},{twist_base.angular.z:.2f})")
                    else:
                        # 没有激活的运动指令时发布零速度
                        self.cmd_pub.publish(Twist())
                    
                except (tf2.LookupException, tf2.ConnectivityException, tf2.ExtrapolationException) as e:
                    rospy.logwarn_throttle(1.0, f"TF错误: {str(e)}")
                    self.cmd_pub.publish(Twist())
                except Exception as e:
                    rospy.logwarn_throttle(1.0, f"控制错误: {str(e)}")
                    self.cmd_pub.publish(Twist())
                    
                rate.sleep()
                
        finally:
            # 退出时停止机器人
            self.cmd_pub.publish(Twist())
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.settings)
    
    def transform_twist_to_ee(self, twist_cam):
        """将速度指令从相机坐标系转换到末端坐标系"""
        cam_to_ee_tf = self.get_transform(self.ee_frame, self.camera_frame)
        
        rotation = cam_to_ee_tf.transform.rotation
        R_cam_to_ee = tf3d.quaternions.quat2mat([
            rotation.w, 
            rotation.x, 
            rotation.y, 
            rotation.z
        ])
        
        translation = cam_to_ee_tf.transform.translation
        t_cam_to_ee = np.array([translation.x, translation.y, translation.z])
        
        skew_sym = np.array([
            [0, -t_cam_to_ee[2], t_cam_to_ee[1]],
            [t_cam_to_ee[2], 0, -t_cam_to_ee[0]],
            [-t_cam_to_ee[1], t_cam_to_ee[0], 0]
        ])
        skew_R = skew_sym @ R_cam_to_ee
        
        adjoint = np.zeros((6, 6))
        adjoint[:3, :3] = R_cam_to_ee
        adjoint[:3, 3:] = skew_R
        adjoint[3:, 3:] = R_cam_to_ee
        
        twist_cam_vec = np.array([
            twist_cam.linear.x,
            twist_cam.linear.y,
            twist_cam.linear.z,
            twist_cam.angular.x,
            twist_cam.angular.y,
            twist_cam.angular.z
        ])
        
        twist_ee_vec = adjoint @ twist_cam_vec
        
        twist_ee = Twist()
        twist_ee.linear.x = twist_ee_vec[0]
        twist_ee.linear.y = twist_ee_vec[1]
        twist_ee.linear.z = twist_ee_vec[2]
        twist_ee.angular.x = twist_ee_vec[3]
        twist_ee.angular.y = twist_ee_vec[4]
        twist_ee.angular.z = twist_ee_vec[5]
        
        return twist_ee

    def transform_twist_to_base(self, twist_ee):
        """将速度指令从末端坐标系转换到基座坐标系"""
        ee_to_base_tf = self.get_transform(self.base_frame, self.ee_frame)
        
        rotation = ee_to_base_tf.transform.rotation
        R_ee_to_base = tf3d.quaternions.quat2mat([
            rotation.w, 
            rotation.x, 
            rotation.y, 
            rotation.z
        ])
        
        twist_ee_vec = np.array([
            twist_ee.linear.x,
            twist_ee.linear.y,
            twist_ee.linear.z,
            twist_ee.angular.x,
            twist_ee.angular.y,
            twist_ee.angular.z
        ])
        
        twist_base_vec = np.zeros(6)
        twist_base_vec[:3] = R_ee_to_base @ twist_ee_vec[:3]
        twist_base_vec[3:] = R_ee_to_base @ twist_ee_vec[3:]
        
        twist_base = Twist()
        twist_base.linear.x = twist_base_vec[0]
        twist_base.linear.y = twist_base_vec[1]
        twist_base.linear.z = twist_base_vec[2]
        twist_base.angular.x = twist_base_vec[3]
        twist_base.angular.y = twist_base_vec[4]
        twist_base.angular.z = twist_base_vec[5]
        
        return twist_base

    def get_transform(self, target_frame, source_frame):
        """获取坐标系间的变换"""
        return self.tf_buffer.lookup_transform(
            target_frame,
            source_frame,
            rospy.Time(0),
            rospy.Duration(0.1))

if __name__ == '__main__':
    try:
        controller = CameraKeyboardControl()
        controller.run()
    except rospy.ROSInterruptException:
        rospy.loginfo("控制器已关闭")