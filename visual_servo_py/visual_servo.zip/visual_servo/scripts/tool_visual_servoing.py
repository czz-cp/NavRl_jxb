#!/usr/bin/env python3
import rospy
import numpy as np
import transforms3d as tf3d
from geometry_msgs.msg import PoseStamped, Twist, Point, Quaternion
from tf2_ros import Buffer, TransformListener, TransformStamped
import tf2_geometry_msgs
import tf2_py as tf2

class CameraPBVSController:
    def __init__(self):
        rospy.init_node('camera_pbvs_controller')
        
        # 坐标系配置
        self.base_frame = "base"
        self.ee_frame = "tool0_controller"
        self.camera_frame = "camera_link"
        self.aruco_frame = "aruco_marker"
        
        # 控制参数
        self.lambda_lin = 4
        self.lambda_ang = 4
        self.max_lin_vel = 3
        self.max_ang_vel = 1.5
        self.error_threshold = 0.005
        self.angle_threshold = 0.02
        
        # 期望的ArUco在相机坐标系下的位姿
        self.desired_position_in_cam = np.array([0.0, 0.0, 0.4])
        
        # 期望姿态：z轴朝向相反 (绕X轴旋转180度)
        self.desired_euler_in_cam = np.array([np.pi, 0.0, 0.0])
        # self.desired_euler_in_cam = np.array([0, 0.0, 0.0])
        self.desired_quat_in_cam = tf3d.euler.euler2quat(
            self.desired_euler_in_cam[0],
            self.desired_euler_in_cam[1],
            self.desired_euler_in_cam[2],
            axes='sxyz'
        )
        
        # TF工具
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer)
        
        # 订阅者 & 发布者
        rospy.Subscriber("/aruco_pose", PoseStamped, self.aruco_callback)
        self.cmd_pub = rospy.Publisher("/ur10e_robot/twist_controller/command", 
                                      Twist, queue_size=1)
        
        rospy.loginfo("相机坐标系PBVS控制器已启动 (基座坐标系输出)")
        rospy.loginfo(f"期望位姿: 位置={self.desired_position_in_cam}, 欧拉角={np.degrees(self.desired_euler_in_cam)}°")
        
    def aruco_callback(self, msg):
        try:
            if msg == None:
                self.publish_zero_velocity()
            # 步骤1：获取当前ArUco在相机坐标系下的位姿
            aruco_in_cam = msg
            
            # 打印当前ArUco位姿
            current_pos = aruco_in_cam.pose.position
            current_quat = aruco_in_cam.pose.orientation
            rospy.loginfo_throttle(1.0, f"当前ArUco位置: x={current_pos.x:.3f}m, y={current_pos.y:.3f}m, z={current_pos.z:.3f}m")
            
            # 计算当前欧拉角
            current_euler = tf3d.euler.quat2euler(
                [current_quat.w, current_quat.x, current_quat.y, current_quat.z], 
                axes='sxyz'
            )
            rospy.loginfo_throttle(1.0, f"当前ArUco姿态: roll={np.degrees(current_euler[0]):.1f}°, pitch={np.degrees(current_euler[1]):.1f}°, yaw={np.degrees(current_euler[2]):.1f}°")
            
            # 步骤2：计算相机坐标系下的位姿误差
            error_in_cam = self.compute_error_in_cam(aruco_in_cam)
            rospy.loginfo_throttle(1.0, f"相机坐标系误差: 位置=[{error_in_cam[0]:.3f}, {error_in_cam[1]:.3f}, {error_in_cam[2]:.3f}]m, 旋转=[{error_in_cam[3]:.3f}, {error_in_cam[4]:.3f}, {error_in_cam[5]:.3f}]rad")
            
            # 检查是否达到目标精度
            pos_error_magnitude = np.linalg.norm(error_in_cam[:3])
            rot_error_magnitude = np.linalg.norm(error_in_cam[3:])
            
            if pos_error_magnitude < self.error_threshold and rot_error_magnitude < self.angle_threshold:
                rospy.loginfo("已达到目标精度，停止运动")
                self.publish_zero_velocity()
                return
            
            # 步骤3：在相机坐标系下生成速度指令
            twist_cam = self.generate_camera_twist(error_in_cam)
            
            # 步骤4：将速度指令从相机坐标系转换到末端坐标系
            twist_ee = self.transform_twist_to_ee(twist_cam, msg.header.stamp)
            
            # 步骤5：将速度指令从末端坐标系转换到基座坐标系
            twist_base = self.transform_twist_to_base(twist_ee, msg.header.stamp)
            
            # 打印速度指令
            rospy.loginfo_throttle(0.5, f"基座坐标系速度指令: 线速度=[{twist_base.linear.x:.3f}, {twist_base.linear.y:.3f}, {twist_base.linear.z:.3f}]m/s, 角速度=[{twist_base.angular.x:.3f}, {twist_base.angular.y:.3f}, {twist_base.angular.z:.3f}]rad/s")
            
            # 发布指令
            self.cmd_pub.publish(twist_base)
            
        except (tf2.LookupException, tf2.ConnectivityException, tf2.ExtrapolationException) as e:
            rospy.logwarn_throttle(1.0, f"TF错误: {str(e)}")
            self.publish_zero_velocity()
        except Exception as e:
            rospy.logwarn_throttle(1.0, f"控制错误: {str(e)}")
            self.publish_zero_velocity()
        
    def compute_error_in_cam(self, aruco_pose_cam):
        """计算ArUco在相机坐标系下的位姿误差"""
        # 位置误差
        pos_error = np.array([
            self.desired_position_in_cam[0] - aruco_pose_cam.pose.position.x,
            self.desired_position_in_cam[1] - aruco_pose_cam.pose.position.y,
            self.desired_position_in_cam[2] - aruco_pose_cam.pose.position.z
        ])
        
        # 获取当前姿态的四元数
        q_current = np.array([
            aruco_pose_cam.pose.orientation.w,
            aruco_pose_cam.pose.orientation.x,
            aruco_pose_cam.pose.orientation.y,
            aruco_pose_cam.pose.orientation.z
        ])
        
        # 计算旋转误差 (desired * current_inverse)。这表示将当前姿态旋转到期望姿态所需的旋转。
        # q_error 对应旋转向量时，其方向表示从 当前 到 期望 的旋转。
        q_current_inv = tf3d.quaternions.qinverse(q_current)
        q_error = tf3d.quaternions.qmult(self.desired_quat_in_cam, q_current_inv) 
        
        # 转换为轴角表示（旋转向量）
        angle = 2 * np.arccos(np.clip(q_error[0], -1.0, 1.0))  # w分量是q_error[0]
        if np.abs(angle) < 1e-6:
            rot_error = np.zeros(3)
        else:
            # 确保轴向量是单位向量
            axis = q_error[1:] / np.linalg.norm(q_error[1:])
            rot_error = angle * axis
        
        return np.concatenate([pos_error, rot_error])
    
    def generate_camera_twist(self, error):
        """在相机坐标系下生成Twist指令"""
        v_cmd = np.zeros(6)
        v_cmd[:3] = -self.lambda_lin * error[:3]  # 线速度
        v_cmd[3:] = -self.lambda_ang * error[3:]  # 角速度

        # 速度限幅
        lin_vel = np.clip(v_cmd[:3], -self.max_lin_vel, self.max_lin_vel)
        ang_vel = np.clip(v_cmd[3:], -self.max_ang_vel, self.max_ang_vel)

        twist_msg = Twist()
        twist_msg.linear.x = lin_vel[0]
        twist_msg.linear.y = lin_vel[1]
        twist_msg.linear.z = lin_vel[2]
        twist_msg.angular.x = ang_vel[0]
        twist_msg.angular.y = ang_vel[1]
        twist_msg.angular.z = ang_vel[2]

        return twist_msg
    
    def transform_twist_to_ee(self, twist_cam, stamp):
        """将速度指令从相机坐标系转换到末端坐标系"""
        # 获取相机到末端的变换
        cam_to_ee_tf = self.get_transform(self.ee_frame, self.camera_frame, stamp)
        
        # 提取旋转矩阵
        rotation = cam_to_ee_tf.transform.rotation
        R_cam_to_ee = tf3d.quaternions.quat2mat([
            rotation.w, 
            rotation.x, 
            rotation.y, 
            rotation.z
        ])
        
        # 提取平移向量
        translation = cam_to_ee_tf.transform.translation
        t_cam_to_ee = np.array([translation.x, translation.y, translation.z])
        
        # 构造伴随矩阵 (6x6)
        # [ R,   [t]×R ]
        # [ 0,    R    ]
        skew_sym = np.array([
            [0, -t_cam_to_ee[2], t_cam_to_ee[1]],
            [t_cam_to_ee[2], 0, -t_cam_to_ee[0]],
            [-t_cam_to_ee[1], t_cam_to_ee[0], 0]
        ])
        skew_R = skew_sym @ R_cam_to_ee
        
        # 构造伴随矩阵 (6x6)
        adjoint = np.zeros((6, 6))
        adjoint[:3, :3] = R_cam_to_ee
        adjoint[:3, 3:] = skew_R
        adjoint[3:, 3:] = R_cam_to_ee
        
        # 将速度向量从相机坐标系转换到末端坐标系
        twist_cam_vec = np.array([
            twist_cam.linear.x,
            twist_cam.linear.y,
            twist_cam.linear.z,
            twist_cam.angular.x,
            twist_cam.angular.y,
            twist_cam.angular.z
        ])
        
        twist_ee_vec = adjoint @ twist_cam_vec
        
        # 转换为Twist消息
        twist_ee = Twist()
        twist_ee.linear.x = twist_ee_vec[0]
        twist_ee.linear.y = twist_ee_vec[1]
        twist_ee.linear.z = twist_ee_vec[2]
        twist_ee.angular.x = twist_ee_vec[3]
        twist_ee.angular.y = twist_ee_vec[4]
        twist_ee.angular.z = twist_ee_vec[5]
        
        return twist_ee

    def transform_twist_to_base(self, twist_ee, stamp):
        """将速度指令从末端坐标系转换到基座坐标系"""
        # 获取末端到基座的变换
        ee_to_base_tf = self.get_transform(self.base_frame, self.ee_frame, stamp)
        
        # 提取旋转矩阵
        rotation = ee_to_base_tf.transform.rotation
        R_ee_to_base = tf3d.quaternions.quat2mat([
            rotation.w, 
            rotation.x, 
            rotation.y, 
            rotation.z
        ])
        
        # 将速度向量从末端坐标系转换到基座坐标系
        twist_ee_vec = np.array([
            twist_ee.linear.x,
            twist_ee.linear.y,
            twist_ee.linear.z,
            twist_ee.angular.x,
            twist_ee.angular.y,
            twist_ee.angular.z
        ])
        
        # 线速度转换: v_base = R * v_ee
        # 角速度转换: ω_base = R * ω_ee
        twist_base_vec = np.zeros(6)
        twist_base_vec[:3] = R_ee_to_base @ twist_ee_vec[:3]
        twist_base_vec[3:] = R_ee_to_base @ twist_ee_vec[3:]
        
        # 转换为Twist消息
        twist_base = Twist()
        twist_base.linear.x = twist_base_vec[0]
        twist_base.linear.y = twist_base_vec[1]
        twist_base.linear.z = twist_base_vec[2]
        twist_base.angular.x = twist_base_vec[3]
        twist_base.angular.y = twist_base_vec[4]
        twist_base.angular.z = twist_base_vec[5]
        
        return twist_base

    def get_transform(self, target_frame, source_frame, time):
        """获取坐标系间的变换"""
        return self.tf_buffer.lookup_transform(
            target_frame,
            source_frame,
            time,
            rospy.Duration(0.1))
    
    def publish_zero_velocity(self):
        """发布零速度指令"""
        zero_twist = Twist()
        self.cmd_pub.publish(zero_twist)
    
    def run(self):
        rospy.spin()

if __name__ == '__main__':
    try:
        controller = CameraPBVSController()
        controller.run()
    except rospy.ROSInterruptException:
        rospy.loginfo("控制器已关闭")
        controller.publish_zero_velocity()