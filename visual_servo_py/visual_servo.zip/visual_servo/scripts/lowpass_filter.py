import numpy as np

class LowPassFilter:
    def __init__(self, cutoff_freq, init_value, dt=0.01):
        """
        低通滤波器实现
        :param cutoff_freq: 截止频率 (Hz)
        :param init_value: 初始值 (数组或标量)
        :param dt: 采样时间间隔 (秒)
        """
        self.cutoff_freq = cutoff_freq
        self.alpha = self.calculate_alpha(cutoff_freq, dt)
        self.prev_value = np.array(init_value, dtype=np.float64)
        
    @staticmethod
    def calculate_alpha(cutoff, dt):
        """计算滤波系数alpha"""
        rc = 1.0 / (2 * np.pi * cutoff)
        return dt / (rc + dt)
    
    def update(self, new_value, dt):
        """
        更新滤波器
        :param new_value: 新测量值
        :param dt: 当前时间间隔
        :return: 滤波后的值
        """
        # 动态更新alpha
        self.alpha = self.calculate_alpha(self.cutoff_freq, dt)
        
        # 应用低通滤波
        filtered = self.alpha * np.array(new_value) + (1 - self.alpha) * self.prev_value
        self.prev_value = filtered
        return filtered