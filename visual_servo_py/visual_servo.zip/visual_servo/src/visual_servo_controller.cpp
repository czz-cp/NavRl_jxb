#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <geometry_msgs/PoseStamped.h>
#include <sensor_msgs/JointState.h>
#include <tf2_ros/transform_listener.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
//Noetic 应该使用 message_filters/sync_policies/approximate_time.h
//如果你在使用较旧的ROS版本，可能需要使用 message_filters/time_synchronizer.h
#include <message_filters/sync_policies/approximate_time.h>  // 必须包含这个头文件
#include <message_filters/time_synchronizer.h>
#include <message_filters/subscriber.h>
#include <message_filters/synchronizer.h>
#include <algorithm>
#include <Eigen/Geometry>
#include <Eigen/Dense>

class VisualServo {
public:
    VisualServo() : nh("~"), tf_buffer(ros::Duration(10.0)), tf_listener(tf_buffer) {
        // 参数加载
        nh.param("target_x", target_pos(0), 0.0);
        nh.param("target_y", target_pos(1), 0.0);
        nh.param("target_z", target_pos(2), 0.3);
        nh.param("Kp_linear", Kp_linear, 0.5);
        nh.param("Kp_angular", Kp_angular, 0.5);

        // 同步订阅
        aruco_sub.subscribe(nh, "/aruco_pose", 10);
        joint_sub.subscribe(nh, "/ur10e_robot/joint_states", 10);
        // sync.reset(new Sync(ArucoJointSyncPolicy(10), aruco_sub, joint_sub));
        // 创建同步器
        sync.reset(new message_filters::Synchronizer<ArucoJointSyncPolicy>(ArucoJointSyncPolicy(10), aruco_sub, joint_sub));

        sync->registerCallback(boost::bind(&VisualServo::syncCallback, this, _1, _2));

        cmd_pub = nh.advertise<geometry_msgs::Twist>("/ur10e_robot/twist_controller/command", 5);
    }

    void syncCallback(const geometry_msgs::PoseStampedConstPtr& aruco_msg,
                    const sensor_msgs::JointStateConstPtr& joint_msg) {
         try {
            // 1. 获取相机到末端的变换
            geometry_msgs::TransformStamped camera_to_ee;
            try {
                camera_to_ee = tf_buffer.lookupTransform("tool0", aruco_msg->header.frame_id, ros::Time(0));
            } catch (tf2::TransformException &ex) {
                ROS_WARN("TF lookup failed: %s", ex.what());
                publishZeroTwist();
                return;
            }

            // 2. 将ArUco位姿转换到末端坐标系
            geometry_msgs::PoseStamped aruco_in_ee;
            tf2::doTransform(*aruco_msg, aruco_in_ee, camera_to_ee);

            // 3. 提取当前位姿
            Eigen::Vector3d current_pos(
                aruco_in_ee.pose.position.x,
                aruco_in_ee.pose.position.y,
                aruco_in_ee.pose.position.z
            );

            Eigen::Quaterniond current_q(
                aruco_in_ee.pose.orientation.w,
                aruco_in_ee.pose.orientation.x,
                aruco_in_ee.pose.orientation.y,
                aruco_in_ee.pose.orientation.z
            );
            // 目标位姿：在相机坐标系中，ArUco 应该位于 (0, 0, 0.3)
            Eigen::Vector3d target_pos(0.0, 0.0, 0.3);
            Eigen::Quaterniond target_q(0.0, -1.0, 0.0, 0.0); 

            // 计算位置误差
            Eigen::Vector3d pos_error = target_pos - current_pos;

            // 计算姿态误差（四元数差值）
            Eigen::Quaterniond delta_q = target_q * current_q.conjugate();
            Eigen::AngleAxisd delta_rot(delta_q);
            Eigen::Vector3d rot_error = delta_rot.axis() * delta_rot.angle();

            // 打印误差信息
            ROS_INFO("Position Error: x=%.4f, y=%.4f, z=%.4f",
                    pos_error.x(), pos_error.y(), pos_error.z());
            ROS_INFO("Rotation Error: x=%.4f, y=%.4f, z=%.4f",
                    rot_error.x(), rot_error.y(), rot_error.z());

            // 构造 Twist 消息（线速度 + 角速度）
            geometry_msgs::Twist twist;
            twist.linear.x = -Kp_linear * pos_error.x();
            twist.linear.y = -Kp_linear * pos_error.y();
            twist.linear.z = Kp_linear * pos_error.z();

            twist.angular.x = Kp_angular * rot_error.x();
            twist.angular.y = Kp_angular * rot_error.y();
            twist.angular.z = Kp_angular * rot_error.z();

            // 安全限制（可选）
            limitTwist(twist);

            // 发布速度指令
            cmd_pub.publish(twist);

        } catch (const std::exception& ex) {
            ROS_WARN("Exception in syncCallback: %s", ex.what());
        }
    }

private:
    void limitTwist(geometry_msgs::Twist& twist) {
        const double max_linear = 0.2;
        const double max_angular = 0.5;

        twist.linear.x = std::clamp(twist.linear.x, -max_linear, max_linear);
        twist.linear.y = std::clamp(twist.linear.y, -max_linear, max_linear);
        twist.linear.z = std::clamp(twist.linear.z, -max_linear, max_linear);

        twist.angular.x = std::clamp(twist.angular.x, -max_angular, max_angular);
        twist.angular.y = std::clamp(twist.angular.y, -max_angular, max_angular);
        twist.angular.z = std::clamp(twist.angular.z, -max_angular, max_angular);
    }
    void publishZeroTwist() {
        geometry_msgs::Twist twist;
        cmd_pub.publish(twist);
    }

    ros::NodeHandle nh;
    message_filters::Subscriber<geometry_msgs::PoseStamped> aruco_sub;
    message_filters::Subscriber<sensor_msgs::JointState> joint_sub;
    // typedef message_filters::sync_policies::ApproximateTime<geometry_msgs::PoseStamped, sensor_msgs::JointState> ArucoJointSyncPolicy;
    typedef message_filters::sync_policies::ApproximateTime<geometry_msgs::PoseStamped, sensor_msgs::JointState> ArucoJointSyncPolicy;
    boost::shared_ptr<message_filters::Synchronizer<ArucoJointSyncPolicy>> sync;

    tf2_ros::Buffer tf_buffer;
    tf2_ros::TransformListener tf_listener;
    ros::Publisher cmd_pub;

    Eigen::Vector3d target_pos;
    double Kp_linear, Kp_angular;
};

// [之前的头文件包含和VisualServo类定义...]

int main(int argc, char** argv) {
    // 初始化ROS节点
    ros::init(argc, argv, "visual_servo_controller");
    // 创建控制器实例
    VisualServo visual_servo;
    // 进入ROS事件循环
    ros::spin();
    
    return 0;
}